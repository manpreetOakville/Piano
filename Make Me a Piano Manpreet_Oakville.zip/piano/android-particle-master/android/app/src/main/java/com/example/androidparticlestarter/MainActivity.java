package com.example.androidparticlestarter;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import io.particle.android.sdk.cloud.ParticleCloud;
import io.particle.android.sdk.cloud.ParticleCloudSDK;
import io.particle.android.sdk.cloud.ParticleDevice;
import io.particle.android.sdk.cloud.ParticleEvent;
import io.particle.android.sdk.cloud.ParticleEventHandler;
import io.particle.android.sdk.cloud.exceptions.ParticleCloudException;
import io.particle.android.sdk.utils.Async;

public class MainActivity extends AppCompatActivity {


    private final String TAG="";

    //  Buttons
    Button a, b, c, d , e, f ,g ;

    // Account Info
    private final String PARTICLE_USERNAME = "manpreet@gmail.com";
    private final String PARTICLE_PASSWORD = "Nimarjot7";

    // MARK: Particle device-specific info
    private final String DEVICE_ID = "38002d001e45273330043435";

    // MARK: Particle Publish
    private long subscriptionId;

    // MARK: Particle device
    private ParticleDevice mDevice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        a = findViewById(R.id.a);
        b = findViewById(R.id.b);
        c = findViewById(R.id.c);
        d = findViewById(R.id.d);
        e = findViewById(R.id.e);
        f = findViewById(R.id.f);
         g = findViewById(R.id.g);


        // 1. Initialize your connection to the Particle API
        ParticleCloudSDK.init(this.getApplicationContext());

        // 2. Setup your device variable
        getDeviceFromCloud();
        //ParticleCloudSDK.getCloud().
    }

public void buttonClick(View v)
    {

        switch (v.getId()) {

            case R.id.a:
                Async.executeAsync(ParticleCloudSDK.getCloud(), new Async.ApiWork<ParticleCloud, Object>() {

                    @Override
                    public Object callApi(@NonNull ParticleCloud particleCloud) throws ParticleCloudException, IOException {

                        List<String> param = new ArrayList<String>();
                        param.add("A");
                        try {

                            mDevice.callFunction("key",param);
                        }
                        catch(Exception e)
                        {
                        }
                        return -1;
                    }
                    @Override
                    public void onSuccess(Object o) {
                        Log.d(TAG, "Successfully got device from Cloud");
                    }

                    @Override
                    public void onFailure(ParticleCloudException exception) {
                        Log.d(TAG, exception.getBestMessage());
                    }
                });
                break;

            case R.id.b:
                Async.executeAsync(ParticleCloudSDK.getCloud(), new Async.ApiWork<ParticleCloud, Object>() {

                    @Override
                    public Object callApi(@NonNull ParticleCloud particleCloud) throws ParticleCloudException, IOException {

                        List<String> param = new ArrayList<String>();
                        param.add("B");
                        try {

                            mDevice.callFunction("key",param);
                        }
                        catch(Exception e)
                        {
                        }
                        return -1;
                    }
                    @Override
                    public void onSuccess(Object o) {
                        Log.d(TAG, "Successfully got device from Cloud");
                    }

                    @Override
                    public void onFailure(ParticleCloudException exception) {
                        Log.d(TAG, exception.getBestMessage());
                    }
                });
                break;

            case R.id.c:
                Async.executeAsync(ParticleCloudSDK.getCloud(), new Async.ApiWork<ParticleCloud, Object>() {

                    @Override
                    public Object callApi(@NonNull ParticleCloud particleCloud) throws ParticleCloudException, IOException {

                        List<String> param = new ArrayList<String>();
                        param.add("C");
                        try {

                            mDevice.callFunction("key",param);
                        }
                        catch(Exception e)
                        {
                        }
                        return -1;
                    }
                    @Override
                    public void onSuccess(Object o) {
                        Log.d(TAG, "Successfully got device from Cloud");
                    }

                    @Override
                    public void onFailure(ParticleCloudException exception) {
                        Log.d(TAG, exception.getBestMessage());
                    }
                });
                break;

            case R.id.d:
                Async.executeAsync(ParticleCloudSDK.getCloud(), new Async.ApiWork<ParticleCloud, Object>() {

                    @Override
                    public Object callApi(@NonNull ParticleCloud particleCloud) throws ParticleCloudException, IOException {

                        List<String> param = new ArrayList<String>();
                        param.add("D");
                        try {

                            mDevice.callFunction("key",param);
                        }
                        catch(Exception e)
                        {
                        }
                        return -1;
                    }
                    @Override
                    public void onSuccess(Object o) {
                        Log.d(TAG, "Successfully got device from Cloud");
                    }

                    @Override
                    public void onFailure(ParticleCloudException exception) {
                        Log.d(TAG, exception.getBestMessage());
                    }
                });
                break;

            case R.id.e:
                Async.executeAsync(ParticleCloudSDK.getCloud(), new Async.ApiWork<ParticleCloud, Object>() {

                    @Override
                    public Object callApi(@NonNull ParticleCloud particleCloud) throws ParticleCloudException, IOException {

                        List<String> param = new ArrayList<String>();
                        param.add("E");
                        try {

                            mDevice.callFunction("key",param);
                        }
                        catch(Exception e)
                        {
                        }
                        return -1;
                    }
                    @Override
                    public void onSuccess(Object o) {
                        Log.d(TAG, "Successfully got device from Cloud");
                    }

                    @Override
                    public void onFailure(ParticleCloudException exception) {
                        Log.d(TAG, exception.getBestMessage());
                    }
                });
                break;

            case R.id.f:
                Async.executeAsync(ParticleCloudSDK.getCloud(), new Async.ApiWork<ParticleCloud, Object>() {

                    @Override
                    public Object callApi(@NonNull ParticleCloud particleCloud) throws ParticleCloudException, IOException {

                        List<String> param = new ArrayList<String>();
                        param.add("F");
                        try {

                            mDevice.callFunction("key",param);
                        }
                        catch(Exception e)
                        {
                        }
                        return -1;
                    }
                    @Override
                    public void onSuccess(Object o) {
                        Log.d(TAG, "Successfully got device from Cloud");
                    }

                    @Override
                    public void onFailure(ParticleCloudException exception) {
                        Log.d(TAG, exception.getBestMessage());
                    }
                });
                break;

                
            case R.id.g:
                Async.executeAsync(ParticleCloudSDK.getCloud(), new Async.ApiWork<ParticleCloud, Object>() {
                    
                    @Override
                    public Object callApi(@NonNull ParticleCloud particleCloud) throws ParticleCloudException, IOException {
                        
                        List<String> param = new ArrayList<String>();
                        param.add("G");
                        try {
                            
                            mDevice.callFunction("key",param);
                        }
                        catch(Exception e)
                        {
                        }
                        return -1;
                    }
                    @Override
                    public void onSuccess(Object o) {
                        Log.d(TAG, "Successfully got device from Cloud");
                    }
                    
                    @Override
                    public void onFailure(ParticleCloudException exception) {
                        Log.d(TAG, exception.getBestMessage());
                    }
                });
                break;




        }

    }

/**
     * function to connect to the Particle
     */
    public void getDeviceFromCloud() {

        Async.executeAsync(ParticleCloudSDK.getCloud(), new Async.ApiWork<ParticleCloud, Object>() {

            @Override
            public Object callApi(@NonNull ParticleCloud particleCloud) throws ParticleCloudException, IOException {
                particleCloud.logIn(PARTICLE_USERNAME, PARTICLE_PASSWORD);
                mDevice = particleCloud.getDevice(DEVICE_ID);
                return -1;
            }

            @Override
            public void onSuccess(Object o) {
                Log.d(TAG, "Successfully got device from Cloud");
            }

            @Override
            public void onFailure(ParticleCloudException exception) {
                Log.d(TAG, exception.getBestMessage());
            }
        });
    }

}
